#ifndef FGUI_H_INCLUDED
#define FGUI_H_INCLUDED
int Login();
void RootFGui();
void ReaderFGui();

#endif